import { NextResponse } from "next/server";

export const runtime = "edge";

type CheckStatus = "pass" | "warn" | "fail" | "unknown";

type AuditCheck = {
  id: string;
  label: string;
  value: string;
  status: CheckStatus;
  recommendation?: string;
};

type SourceStatus = "ok" | "unavailable" | "not_configured";

type SourceInfo = {
  name: string;
  status: SourceStatus;
  message: string;
};

const REQUEST_TIMEOUT_MS = 18000;
const USER_AGENT =
  "Mozilla/5.0 (compatible; ElitWebAudit/1.0; +https://elit-web.ua/ua/)";

function envValue(key: string) {
  const env = globalThis as typeof globalThis & {
    process?: { env?: Record<string, string | undefined> };
  };
  return env.process?.env?.[key];
}

function normalizeUrl(input: unknown) {
  if (typeof input !== "string") {
    throw new Error("URL має бути текстом.");
  }

  const trimmed = input.trim();
  if (!trimmed) {
    throw new Error("Введіть URL сайту.");
  }

  const withProtocol = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;
  const parsed = new URL(withProtocol);

  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Підтримуються тільки http або https URL.");
  }

  parsed.hash = "";
  return parsed;
}

function domainFromUrl(url: URL) {
  return url.hostname.replace(/^www\./, "");
}

function byteSize(text: string) {
  return new TextEncoder().encode(text).length;
}

function decodeHtml(value: string) {
  return value
    .replaceAll("&amp;", "&")
    .replaceAll("&quot;", '"')
    .replaceAll("&#039;", "'")
    .replaceAll("&apos;", "'")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function stripTags(value: string) {
  return decodeHtml(value.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim());
}

function tagAttributes(tag: string) {
  const attrs: Record<string, string> = {};
  const matches = tag.matchAll(
    /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/g,
  );

  for (const match of matches) {
    attrs[match[1].toLowerCase()] = decodeHtml(
      match[2] ?? match[3] ?? match[4] ?? "",
    );
  }

  return attrs;
}

function firstTagContent(html: string, tagName: string) {
  const match = html.match(
    new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}>`, "i"),
  );
  return match ? stripTags(match[1]) : "";
}

function countTags(html: string, tagName: string) {
  return Array.from(html.matchAll(new RegExp(`<${tagName}\\b[^>]*>`, "gi")))
    .length;
}

function metaContent(html: string, keys: string[]) {
  const wanted = new Set(keys.map((key) => key.toLowerCase()));
  const metas = html.matchAll(/<meta\b[^>]*>/gi);

  for (const meta of metas) {
    const attrs = tagAttributes(meta[0]);
    const key = (attrs.name ?? attrs.property ?? "").toLowerCase();
    if (wanted.has(key)) {
      return attrs.content ?? "";
    }
  }

  return "";
}

function linkHref(html: string, rel: string) {
  const links = html.matchAll(/<link\b[^>]*>/gi);
  const wanted = rel.toLowerCase();

  for (const link of links) {
    const attrs = tagAttributes(link[0]);
    const rels = (attrs.rel ?? "").toLowerCase().split(/\s+/);
    if (rels.includes(wanted)) {
      return attrs.href ?? "";
    }
  }

  return "";
}

function imageStats(html: string) {
  const images = Array.from(html.matchAll(/<img\b[^>]*>/gi));
  const missingAlt = images.filter((image) => {
    const attrs = tagAttributes(image[0]);
    return !attrs.alt?.trim();
  });

  return {
    total: images.length,
    missingAlt: missingAlt.length,
  };
}

function sourceOk(response: Response) {
  return response.status >= 200 && response.status < 400;
}

async function fetchWithTimeout(input: RequestInfo | URL, init?: RequestInit) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    return await fetch(input, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function checkAsset(url: URL, path: string) {
  const assetUrl = new URL(path, url.origin);

  try {
    const response = await fetchWithTimeout(assetUrl, {
      headers: { "user-agent": USER_AGENT },
      redirect: "follow",
    });

    return {
      url: assetUrl.toString(),
      status: response.status,
      ok: sourceOk(response),
    };
  } catch {
    return {
      url: assetUrl.toString(),
      status: null,
      ok: false,
    };
  }
}

async function checkFirstAvailableAsset(url: URL, paths: string[]) {
  let fallback: Awaited<ReturnType<typeof checkAsset>> | null = null;

  for (const path of paths) {
    const result = await checkAsset(url, path);
    fallback ??= result;
    if (result.ok) return result;
  }

  return fallback ?? checkAsset(url, paths[0]);
}

function checkStatus(condition: boolean, warnCondition = false): CheckStatus {
  if (condition) return "pass";
  return warnCondition ? "warn" : "fail";
}

async function inspectPage(url: URL) {
  const startedAt = Date.now();
  const response = await fetchWithTimeout(url, {
    headers: { "user-agent": USER_AGENT, accept: "text/html,*/*" },
    redirect: "follow",
  });
  const responseMs = Date.now() - startedAt;
  const html = await response.text();
  const finalUrl = response.url || url.toString();
  const final = new URL(finalUrl);
  const title = firstTagContent(html, "title");
  const description = metaContent(html, ["description"]);
  const robotsMeta = metaContent(html, ["robots"]);
  const canonical = linkHref(html, "canonical");
  const ogTitle = metaContent(html, ["og:title"]);
  const ogDescription = metaContent(html, ["og:description"]);
  const h1 = firstTagContent(html, "h1");
  const headingCounts = {
    h1: countTags(html, "h1"),
    h2: countTags(html, "h2"),
    h3: countTags(html, "h3"),
  };
  const images = imageStats(html);
  const structuredDataCount = Array.from(
    html.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>/gi),
  ).length;
  const robots = await checkAsset(final, "/robots.txt");
  const sitemap = await checkFirstAvailableAsset(final, [
    "/sitemap.xml",
    "/sitemap_index.xml",
  ]);
  const sizeBytes = byteSize(html);
  const isHtml = (response.headers.get("content-type") ?? "").includes("html");
  const noindex = /noindex/i.test(robotsMeta);

  const checks: AuditCheck[] = [
    {
      id: "http-status",
      label: "HTTP-статус",
      value: String(response.status),
      status: checkStatus(sourceOk(response)),
      recommendation: sourceOk(response)
        ? undefined
        : "Перевірте доступність сторінки та редиректи.",
    },
    {
      id: "https",
      label: "HTTPS",
      value: final.protocol === "https:" ? "Так" : "Ні",
      status: checkStatus(final.protocol === "https:"),
      recommendation: "Переведіть сторінку на HTTPS.",
    },
    {
      id: "content-type",
      label: "HTML-відповідь",
      value: response.headers.get("content-type") ?? "немає заголовка",
      status: checkStatus(isHtml),
      recommendation: "Сторінка має повертати HTML-контент для аудиту.",
    },
    {
      id: "title",
      label: "Title",
      value: title ? `${title.length} символів` : "не знайдено",
      status: title
        ? checkStatus(title.length >= 30 && title.length <= 70, true)
        : "fail",
      recommendation: title
        ? "Тримайте title у межах 30-70 символів і додайте головний запит."
        : "Додайте унікальний title для сторінки.",
    },
    {
      id: "description",
      label: "Meta description",
      value: description ? `${description.length} символів` : "не знайдено",
      status: description
        ? checkStatus(description.length >= 70 && description.length <= 165, true)
        : "fail",
      recommendation: description
        ? "Оптимізуйте description під користь для користувача та CTR."
        : "Додайте meta description.",
    },
    {
      id: "h1",
      label: "H1",
      value: `${headingCounts.h1} шт.`,
      status: checkStatus(headingCounts.h1 === 1, headingCounts.h1 > 1),
      recommendation:
        headingCounts.h1 === 0
          ? "Додайте один H1 із основною темою сторінки."
          : "Залиште один основний H1 на сторінці.",
    },
    {
      id: "canonical",
      label: "Canonical",
      value: canonical || "не знайдено",
      status: canonical ? "pass" : "warn",
      recommendation: "Додайте canonical, якщо сторінка може дублюватися.",
    },
    {
      id: "robots-meta",
      label: "Meta robots",
      value: robotsMeta || "не вказано",
      status: noindex ? "fail" : "pass",
      recommendation: "Перевірте noindex, якщо сторінка має ранжуватися.",
    },
    {
      id: "images-alt",
      label: "Alt у зображень",
      value:
        images.total > 0
          ? `${images.missingAlt} без alt із ${images.total}`
          : "зображень не знайдено",
      status:
        images.total === 0
          ? "unknown"
          : checkStatus(images.missingAlt === 0, images.missingAlt < images.total),
      recommendation: "Додайте описові alt до важливих зображень.",
    },
    {
      id: "structured-data",
      label: "Schema.org / JSON-LD",
      value: `${structuredDataCount} блоків`,
      status: structuredDataCount > 0 ? "pass" : "warn",
      recommendation: "Додайте релевантну мікророзмітку для сторінки.",
    },
    {
      id: "open-graph",
      label: "Open Graph",
      value: ogTitle || ogDescription ? "є базові теги" : "не знайдено",
      status: ogTitle || ogDescription ? "pass" : "warn",
      recommendation: "Додайте og:title і og:description для прев'ю в соцмережах.",
    },
    {
      id: "robots-txt",
      label: "robots.txt",
      value: robots.status ? String(robots.status) : "не відповідає",
      status: robots.ok ? "pass" : "warn",
      recommendation: "Перевірте robots.txt на домені.",
    },
    {
      id: "sitemap",
      label: "sitemap.xml",
      value: sitemap.status
        ? `${sitemap.status} (${new URL(sitemap.url).pathname})`
        : "не відповідає",
      status: sitemap.ok ? "pass" : "warn",
      recommendation: "Перевірте sitemap.xml або sitemap index.",
    },
    {
      id: "html-size",
      label: "Розмір HTML",
      value: `${Math.round(sizeBytes / 1024)} КБ`,
      status: checkStatus(sizeBytes < 550_000, sizeBytes < 1_000_000),
      recommendation: "Зменшіть HTML, критичні стилі або зайві скрипти.",
    },
  ];

  const passed = checks.filter((check) => check.status === "pass").length;
  const counted = checks.filter((check) => check.status !== "unknown").length;
  const onPageScore = counted ? Math.round((passed / counted) * 100) : null;

  return {
    source: {
      name: "On-page crawl",
      status: "ok" as const,
      message: "HTML сторінки, заголовки відповіді, robots.txt і sitemap.xml.",
    },
    data: {
      requestedUrl: url.toString(),
      finalUrl,
      domain: domainFromUrl(final),
      fetchedAt: new Date().toISOString(),
      responseMs,
      statusCode: response.status,
      title,
      description,
      h1,
      headingCounts,
      images,
      canonical,
      robotsMeta,
      robots,
      sitemap,
      sizeBytes,
      checks,
      score: onPageScore,
    },
  };
}

function scoreFromLighthouse(value: unknown) {
  return typeof value === "number" ? Math.round(value * 100) : null;
}

function auditDisplayValue(audits: Record<string, { displayValue?: string }>, id: string) {
  return audits[id]?.displayValue ?? null;
}

async function runPageSpeed(url: URL, strategy: string) {
  const apiUrl = new URL("https://www.googleapis.com/pagespeedonline/v5/runPagespeed");
  apiUrl.searchParams.set("url", url.toString());
  apiUrl.searchParams.set("strategy", strategy === "desktop" ? "desktop" : "mobile");
  apiUrl.searchParams.set("locale", "uk");
  for (const category of ["performance", "seo", "accessibility", "best-practices"]) {
    apiUrl.searchParams.append("category", category);
  }

  const key = envValue("PAGESPEED_API_KEY");
  if (key) {
    apiUrl.searchParams.set("key", key);
  }

  try {
    const response = await fetchWithTimeout(apiUrl);
    const payload = await response.json();

    if (!response.ok || payload.error) {
      return {
        source: {
          name: "PageSpeed Insights",
          status: "unavailable" as const,
          message:
            payload.error?.message ??
            `PageSpeed Insights повернув статус ${response.status}.`,
        },
        data: null,
      };
    }

    const lighthouse = payload.lighthouseResult;
    const categories = lighthouse?.categories ?? {};
    const audits = lighthouse?.audits ?? {};

    return {
      source: {
        name: "PageSpeed Insights",
        status: "ok" as const,
        message: "Реальні Lighthouse-метрики від Google PageSpeed Insights.",
      },
      data: {
        strategy: strategy === "desktop" ? "desktop" : "mobile",
        performance: scoreFromLighthouse(categories.performance?.score),
        seo: scoreFromLighthouse(categories.seo?.score),
        accessibility: scoreFromLighthouse(categories.accessibility?.score),
        bestPractices: scoreFromLighthouse(categories["best-practices"]?.score),
        metrics: {
          firstContentfulPaint: auditDisplayValue(audits, "first-contentful-paint"),
          largestContentfulPaint: auditDisplayValue(
            audits,
            "largest-contentful-paint",
          ),
          totalBlockingTime: auditDisplayValue(audits, "total-blocking-time"),
          cumulativeLayoutShift: auditDisplayValue(
            audits,
            "cumulative-layout-shift",
          ),
          speedIndex: auditDisplayValue(audits, "speed-index"),
        },
      },
    };
  } catch (error) {
    return {
      source: {
        name: "PageSpeed Insights",
        status: "unavailable" as const,
        message:
          error instanceof Error
            ? error.message
            : "Не вдалося отримати відповідь PageSpeed.",
      },
      data: null,
    };
  }
}

async function runSerpstat(url: URL) {
  const token = envValue("SERPSTAT_API_TOKEN");
  const se = envValue("SERPSTAT_SE") ?? "g_ua";

  if (!token) {
    return {
      source: {
        name: "Serpstat API",
        status: "not_configured" as const,
        message: "Додайте SERPSTAT_API_TOKEN, щоб отримувати видимість, ключі й трафік.",
      },
      data: null,
    };
  }

  try {
    const response = await fetchWithTimeout(
      `https://api.serpstat.com/v4/?token=${encodeURIComponent(token)}`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: "domain-summary",
          method: "SerpstatDomainProcedure.getDomainsInfo",
          params: {
            domains: [domainFromUrl(url)],
            se,
          },
        }),
      },
    );
    const payload = await response.json();

    if (!response.ok || payload.error) {
      return {
        source: {
          name: "Serpstat API",
          status: "unavailable" as const,
          message:
            payload.error?.message ??
            `Serpstat API повернув статус ${response.status}.`,
        },
        data: null,
      };
    }

    const summary = payload.result?.data?.[0] ?? null;

    return {
      source: {
        name: "Serpstat API",
        status: summary ? ("ok" as const) : ("unavailable" as const),
        message: summary
          ? `Доменні SEO-дані з бази ${se}.`
          : "Serpstat відповів, але даних для домену немає.",
      },
      data: summary
        ? {
            se,
            domain: summary.domain ?? domainFromUrl(url),
            visibility: summary.visible ?? null,
            keywords: summary.keywords ?? null,
            traffic: summary.traff ?? null,
            visibilityDynamic: summary.visible_dynamic ?? null,
            keywordsDynamic: summary.keywords_dynamic ?? null,
            trafficDynamic: summary.traff_dynamic ?? null,
            prevDate: summary.prev_date ?? null,
          }
        : null,
    };
  } catch (error) {
    return {
      source: {
        name: "Serpstat API",
        status: "unavailable" as const,
        message:
          error instanceof Error
            ? error.message
            : "Не вдалося отримати відповідь Serpstat.",
      },
      data: null,
    };
  }
}

function sourceFromError(name: string, error: unknown): SourceInfo {
  return {
    name,
    status: "unavailable",
    message: error instanceof Error ? error.message : "Джерело недоступне.",
  };
}

function severity(status: CheckStatus) {
  if (status === "fail") return "Критично";
  if (status === "warn") return "Важливо";
  return "Інфо";
}

function buildFindings(checks: AuditCheck[]) {
  return checks
    .filter((check) => check.status === "fail" || check.status === "warn")
    .slice(0, 8)
    .map((check) => ({
      level: severity(check.status),
      title: check.label,
      detail: `${check.value}. ${check.recommendation ?? ""}`.trim(),
    }));
}

function average(values: Array<number | null | undefined>) {
  const real = values.filter((value): value is number => typeof value === "number");
  return real.length
    ? Math.round(real.reduce((sum, value) => sum + value, 0) / real.length)
    : null;
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const url = normalizeUrl(body.url);
    const strategy = body.strategy === "desktop" ? "desktop" : "mobile";

    const [pageResult, pageSpeedResult, serpstatResult] = await Promise.allSettled([
      inspectPage(url),
      runPageSpeed(url, strategy),
      runSerpstat(url),
    ]);

    const page =
      pageResult.status === "fulfilled"
        ? pageResult.value
        : {
            source: sourceFromError("On-page crawl", pageResult.reason),
            data: null,
          };
    const pageSpeed =
      pageSpeedResult.status === "fulfilled"
        ? pageSpeedResult.value
        : {
            source: sourceFromError("PageSpeed Insights", pageSpeedResult.reason),
            data: null,
          };
    const serpstat =
      serpstatResult.status === "fulfilled"
        ? serpstatResult.value
        : {
            source: sourceFromError("Serpstat API", serpstatResult.reason),
            data: null,
          };

    const pageScore = page.data?.score ?? null;
    const lighthouseScore = average([
      pageSpeed.data?.performance,
      pageSpeed.data?.seo,
      pageSpeed.data?.accessibility,
      pageSpeed.data?.bestPractices,
    ]);
    const overallScore = average([pageScore, lighthouseScore]);
    const checks = page.data?.checks ?? [];

    return NextResponse.json({
      ok: true,
      url: url.toString(),
      strategy,
      fetchedAt: new Date().toISOString(),
      score: overallScore,
      scoreBasis:
        overallScore === null
          ? "Немає достатньо доступних джерел для розрахунку."
          : "Розраховано тільки з фактично отриманих джерел.",
      sources: [page.source, pageSpeed.source, serpstat.source],
      onPage: page.data,
      pageSpeed: pageSpeed.data,
      serpstat: serpstat.data,
      findings: buildFindings(checks),
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        message:
          error instanceof Error
            ? error.message
            : "Не вдалося запустити аудит.",
      },
      { status: 400 },
    );
  }
}
